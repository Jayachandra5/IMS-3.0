package projectbms;

public class Constants {

    public static String Title = new String("Bussines Managment System ");
    public static String subTitle = new String("Invoice");

    public static String name = new String("K Malleswara Rao ");
    public static String phnNum1 = new String("9848903535");
    public static String PhnNum2 = new String("8712173660");
    public static String gstNum = new String("GSTXXXX5818");
    public static String address = new String("Shop Num 97, K.G Market, 1 town,Vijayawada 520001");

    public static String productDataBase = "jdbc:sqlite:V://projectBms/bmsList1.db";
    
    public static String sellTable = "lastSellTable";

   // public static String productTable = "bmsProductTable"; 

    public static String vendourTable = "vendourTable";

    public static String customerTable = "customerTableWith";
    
    public static String purchaseTable = "lastPurchaseList";
    
    public static String salesTable = "last_Sales_Table";

    public static String expensesTable ="expenses_Table";
    
    
    //New 
     public static String productDB = "jdbc:sqlite:C:\\Ybm/pro1.db";
    
   //  public static String Prod
    public static String employeeDB = "jdbc:sqlite:C:\\Ybm/emp1.db";
    
    public static String mangeDB = "jdbc:sqlite:C:\\Ybm/mange1.db";
    
    public static String reportDB = "jdbc:sqlite:C:\\Ybm/report1.db";
    
    public static String duesDB = "jdbc:sqlite:C:\\Ybm/dues1.db";
}
